package com.teamace.suriya;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SuriyaApplicationTests {

	@Test
	void contextLoads() {
	}

}
